<?php

// CONFIGURATION PARAMETERS

function getTypeFormApiBaseUrl() { return array_key_exists("typeform_baseurl",$_GET)?$_GET["typeform_baseurl"]:"http://localhost"; } // The real one would be https://api.typeform.com
function getTFPAT() { return array_key_exists("typeform_key",$_GET)?$_GET["typeform_key"]:"YOUR_TYPEFORM_ACCESS_KEY_GOES_HERE"; } // Access token to send API requests to TypeForm
function getPotentialClientSurveyFormID() { return array_key_exists("client_form_id",$_GET)?$_GET["client_form_id"]:"exad2bN7"; } // Identifier of the TypeForm survey filled in by potential clients
function getOptionSurveyFormID() { return array_key_exists("option_form_id",$_GET)?$_GET["option_form_id"]:"xNPPsDO0"; } // Identifier of the TypeForm survey used to add options available to the potential client

// DATASOURCE-SPECIFIC UTILITY FUNCTIONS

// Get the list of options - TypeForm responses submitted by the seller(s) - with all the details that are necessary for the ranking.

function getOptions() { 
	
	$opts = array(
	  'http'=>array(
		'method'=>"GET",
		'header'=>"Content-Type: application/json \r\n" .
				  "Authorization: Bearer ".getTFPAT()
	  )
	);
		
	$field_ids = array();
	$form_context = stream_context_create($opts);
	$form = json_decode(file_get_contents(getTypeFormApiBaseUrl()."/forms/".getOptionSurveyFormID(), false,  $form_context),true);
	foreach($form["fields"] as $field) {
		if(!array_key_exists("fields", $field["properties"])) {
			$field_ids[$field["title"]] = $field["id"];
		}
		else {
			foreach($field["properties"]["fields"] as $subfield) {
				$field_ids[$subfield["title"]] = $subfield["id"];
			}
		}		
	}
	
	$pro_list_ctx = stream_context_create($opts);
	$pro_list_ans = json_decode(file_get_contents(getTypeFormApiBaseUrl()."/forms/".getOptionSurveyFormID()."/responses?page_size=".($_GET["pretend_you_have_these_many_options"]?$_GET["pretend_you_have_these_many_options"]:"1000000"), false, $pro_list_ctx),true);
	$options = [];
	foreach($pro_list_ans["items"] as $item) {
		$option = array();
		foreach($item["answers"] as $answer) {
			if($field_ids["In which region the house locates?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["text"];
			if($field_ids["In which county the house locates?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["text"];
			if($field_ids["In which municipality the house locates?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["text"];
			if($field_ids["Is the house near to a bus stop?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["boolean"];
			if($field_ids["Is the house near to a supermarket?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["boolean"];
			if($field_ids["Is the house near to a school?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["boolean"];
			if($field_ids["How much is it in euros?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["number"];
			if($field_ids["How large is the house in squared metres?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["number"];
			if($field_ids["How many rooms are there in the house?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["number"];			
			if($field_ids["Is the furniture sold with the house?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["choice"]["ref"];
			if($field_ids["How many bathrooms are there in the house?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["number"];			
			if($field_ids["At which floor is the house?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["number"];
			if($field_ids["Is an elevator available?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["boolean"];			
			if($field_ids["Is a garden part of this house?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["boolean"];
			if($field_ids["Is there any balcony?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["boolean"];
			if($field_ids["In what condition is the house?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["choice"]["ref"];
			if($field_ids["How old is the house in years?"] == $answer["field"]["id"]) $option[$answer["field"]["ref"]] = $answer["number"];				
			$option["status"] = array( "points" => 0, "advantages" => array(), "disadvantages" => array() );
		}

		array_push($options, $option);
	}

	return $options;
	
}

// Get from TypeForm the survey submitted by a specific client.
 
function getClientResponse($response_id) { 

	$opts = array(
		'http'=>array(
				'method'=>"GET",
			'header'=>"Content-Type: application/json \r\n" .
			"Authorization: Bearer ".getTFPAT()
		)
	);
	
	$form_context = stream_context_create($opts);
	$form = json_decode(file_get_contents(getTypeFormApiBaseUrl()."/forms/".getPotentialClientSurveyFormID(), false,  $form_context),true);	
	$field_ids = array();
	foreach($form["fields"] as $field) {
		if(!array_key_exists("fields", $field["properties"])) {
			$field_ids[$field["title"]] = $field["id"];
		}
		else {
			foreach($field["properties"]["fields"] as $subfield) {
				$field_ids[$subfield["title"]] = $subfield["id"];
			}
		}		
	}
	
	$response_context = stream_context_create($opts);
	$response = json_decode(file_get_contents(getTypeFormApiBaseUrl()."/forms/".getPotentialClientSurveyFormID()."/responses?included_response_ids=$response_id", false,  $response_context),true);
	$client = array();
	foreach($response["items"][0]["answers"] as $answer) {
		if($field_ids["In which region would you like the house to be located?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["text"];
		if($field_ids["In which county would you like the house to be located?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["text"];
		if($field_ids["In which municipality would you like the house to be located?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["text"];
		if($field_ids["Should the house be near to a bus stop?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["boolean"];
		if($field_ids["Should the house be near to a supermarket?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["boolean"];
		if($field_ids["Should the house be near to a school?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["boolean"];
		if($field_ids["How much should the house cost in euros?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["number"];
		if($field_ids["How large should the house be in squared metres?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["number"];
		if($field_ids["How many rooms should be in the house?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["number"];			
		if($field_ids["Should the house come with furniture inside?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["choice"]["ref"];
		if($field_ids["How many bathrooms should be in the house?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["number"];			
		if($field_ids["At which floor should the house be?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["number"];
		if($field_ids["Should an elevator be there?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["boolean"];			
		if($field_ids["Should the house have a garden?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["boolean"];
		if($field_ids["How important is the garden for you?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["choice"]["ref"];
		if($field_ids["How important is not to have a garden for you?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["choice"]["ref"];
		if($field_ids["Should the house have a balcony?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["boolean"];
		if($field_ids["In which conditions should the house be?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["choice"]["ref"];
		if($field_ids["How old should be the house in years?"] == $answer["field"]["id"]) $client[$answer["field"]["ref"]] = $answer["number"];				
	}
	
	return $client;
	
 }
 
 // Get the rules
 
function getRules() {
	if(file_exists("rules.json")) $rules = json_decode(file_get_contents("rules.json"),true); 
	if(!$rules) $rules = [];
	if($_GET["pretend_you_have_these_many_rules"]) { // you do not need this in a production application
		while(count($rules) < $_GET["pretend_you_have_these_many_rules"]) $rules = array_merge($rules,$rules);
		$pretend_rules = array();
		foreach(array_rand($rules, $_GET["pretend_you_have_these_many_rules"]) as $rule_index) {
			array_push($pretend_rules, $rules[$rule_index]);
		}
		$rules = $pretend_rules;
	}
	return $rules;
}
 
?>