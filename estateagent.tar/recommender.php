<?php 

header("Content-Type: application/json");
include_once 'config.php';
include_once 'conditions.php';
include_once 'consequences.php';

// Retrieve all the necessary data
$start = microtime(true);
$options = getOptions();
$client = getClientResponse($_GET["responseid"]);
$rules = getRules();
$end_data = microtime(true);

// Give points to each option
foreach($options as &$option) {
	foreach($rules as $rule) {
		// Go through the conditions configured for this rule, and verify that all of them are satisfied.
		$all_conditions_verified = true;
		foreach($rule["conditions"] as $condition) {
			// Go through the implemented conditions to find the method that implements the condition that we have at hand right now
			$is_verified = false;
			$reflector = new ReflectionClass('Conditions'); 
			foreach($reflector->getMethods() as $method) { 
				if(preg_match("/^(".str_replace("...",")(.*)(",preg_replace('(\\(.*?\\)\\s)',")(.*)(",trim($reflector->getMethod($method->name)->getDocComment(), " /*\n\r"))).")$/", $condition)) { // if $method implements the condition
					// Parse the condition to extract the parameters...
					$params = array();
					$condition_fragments = explode("...",trim($reflector->getMethod($method->name)->getDocComment(), " /*\n\r"));
					for($fragment_no = 0; $fragment_no < count($condition_fragments)-1; $fragment_no++) {
						$matches = array();
						// ...and set matches[0] = parameter value as specified in the condition...
						preg_match("/(?<=".str_replace(") ","",str_replace("(","",$condition_fragments[$fragment_no])).")(.*)(?=".str_replace(") ","",str_replace("(","",$condition_fragments[$fragment_no+1])).")/", $condition, $matches);
						if(!$matches) {
							array_walk($condition_fragments,function(&$value, $key){ $value = preg_replace('(\\(.*?\\)\\s)',"",$value); });
							preg_match("/(?<=".$condition_fragments[$fragment_no].")(.*)(?=".$condition_fragments[$fragment_no+1].")/", $condition, $matches);
						}
						//... if the parameter value specified in the condition references an answer given in some survey, resolve the reference...
						$matches[0] = trim($matches[0]);
						$matches[0] = array_key_exists($matches[0],$client)?$client[$matches[0]]:(array_key_exists($matches[0],$option)?$option[$matches[0]]:$matches[0]);
						//... and add the parameter value to the list of the parameters for the current condition...
						array_push($params, $matches[0]);						
					}	
					// ...and invoke the method that implements the condition to determine if the condition is verified
					array_walk($params, function (&$value, $key) { $value = trim($value,"*"); });					
					$is_verified = $method->invokeArgs(null, array($params));
					break;
				}				
			}
			$all_conditions_verified = $is_verified && $all_conditions_verified;	
			if(!$all_conditions_verified) break;

		}
		
		// Something very similar happens for the consequences
		if($all_conditions_verified) {
			foreach($rule["consequences"] as $consequence) {
				$reflector = new ReflectionClass('Consequences'); 
				foreach($reflector->getMethods() as $method) {
					if(preg_match("/^(".str_replace("...",")(.*)(",preg_replace('(\\(.*?\\)\\s)',")(.*)(",trim($reflector->getMethod($method->name)->getDocComment(), " /*\n\r"))).")$/", $consequence)) {
						$params = array();
						$consequence_fragments = explode("...",trim($reflector->getMethod($method->name)->getDocComment(), " /*\n\r"));
						for($fragment_no = 0; $fragment_no < count($consequence_fragments)-1; $fragment_no++) {
							$matches = array();
							preg_match("/(?<=".str_replace(") ","",str_replace("(","",$consequence_fragments[$fragment_no])).")(.*)(?=".str_replace(") ","",str_replace("(","",$consequence_fragments[$fragment_no+1])).")/", $consequence, $matches);
							if(!$matches) {
								array_walk($consequence_fragments,function(&$value, $key){ $value = preg_replace('(\\(.*?\\)\\s)',"",$value); });
								preg_match("/(?<=".$consequence_fragments[$fragment_no].")(.*)(?=".$consequence_fragments[$fragment_no+1].")/", $condition, $matches);
							}
							$matches[0] = trim($matches[0]);
							$matches[0] = array_key_exists($matches[0],$client)?$client[$matches[0]]:(array_key_exists($matches[0],$option)?$option[$matches[0]]:$matches[0]);
							array_push($params, $matches[0]);						
						}		
						array_walk($params, function (&$value, $key) { $value = trim($value,"*"); });
						$method->invokeArgs(null, array($params, $rule, &$option["status"]));
						break;
					}				
				}
			}
		}
	}
}

// Sort options by points
usort($options, function($opt1, $opt2) { return $opt2["status"]["points"]-$opt1["status"]["points"]; });

// Sort advantages and disadvantages of each option by weight
foreach($options as $pos => $option) {
	usort($options[$pos]["status"]["advantages"], function($adv1, $adv2) { return $adv2["weight"]-$adv1["weight"]; });
	usort($options[$pos]["status"]["disadvantages"], function($disadv1, $disadv2) { return $disadv2["weight"]-$disadv1["weight"]; });
}

// Return the sorted list of the options
$end = microtime(true);
echo(json_encode(array( "recommendations" => $options, "exe_time" => array ( "data" => $end_data-$start, "computation" => $end-$end_data ) ),JSON_PRETTY_PRINT));

?>