<?php

/**
 * Consequences
 */
class Consequences 
{
    
    /**
     * the house gains ... points
     */
    public static function add_points($params, $rule, &$status)
    {		
		$status["points"]+=$params[0];
		array_push($status["advantages"], array( "weight" => 0+$params[0], "description" => $rule["description"] ) );
    }

    /**
     *  the house loses ... points
     */
    public static function remove_points($params, $rule, &$status)
    {
		$status["points"]-=$params[0];
		array_push($status["disadvantages"], array( "weight" => abs($params[0]), "description" => $rule["description"] ) );
    }
	
	/**
     * the house gains as many points as the difference between ... and ...
     */
    public static function add_points_based_on_difference($params, $rule, &$status)
    {		
		$status["points"]+=abs($params[0]-$params[1]);
		array_push($status["advantages"], array( "weight" => abs($params[0]-$params[1]), "description" => $rule["description"] ) );
    }
	
	/**
     * the house gains as many points as ... times the difference between ... and ...
     */
    public static function add_points_based_on_mult_difference($params, $rule, &$status)
    {		
		$status["points"]+=$params[0]*abs($params[1]-$params[2]);
		array_push($status["advantages"], array( "weight" => $params[0]*abs($params[1]-$params[2]), "description" => $rule["description"] ) );
    }

	/**
     * the house loses as many points as the difference between ... and ...
     */
    public static function remove_points_based_on_difference($params, $rule, &$status)
    {		
		$status["points"]-=abs($params[0]-$params[1]);
		array_push($status["disadvantages"], array( "weight" => abs($params[0]-$params[1]), "description" => $rule["description"] ) );
    }
	
	/**
     * the house loses as many points as ... times the difference between ... and ...
     */
    public static function remove_points_based_on_mult_difference($params, $rule, &$status)
    {		
		$status["points"]-=$params[0]*abs($params[1]-$params[2]);
		array_push($status["disadvantages"], array( "weight" => $params[0]*abs($params[1]-$params[2]), "description" => $rule["description"] ) );
    }
	
}

?>