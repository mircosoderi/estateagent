<?php header("Content-Type: application/json"); ?>
{
    "items": [<?php for($i = 0; $i < $_GET["page_size"]; $i++) { ?>
        {
            "landing_id": "e50jwt5l05vum9vmxe50jladxbctsgl8",
            "token": "e50jwt5l05vum9vmxe50jladxbctsgl8",
            "response_id": "e50jwt5l05vum9vmxe50jladxbctsgl8",
            "response_type": "completed",
            "landed_at": "2025-02-11T18:26:07Z",
            "submitted_at": "2025-02-11T18:27:49Z",
            "metadata": {
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
                "platform": "other",
                "referer": "https://44fl7nanstm.typeform.com/to/xNPPsDO0",
                "network_id": "cfdf83fb6b",
                "browser": "default"
            },
            "hidden": {},
            "calculated": {
                "score": 0
            },
            "answers": [
                {
                    "field": {
                        "id": "cOAvPCL98XKr",
                        "type": "short_text",
                        "ref": "the region where the house locates"
                    },
                    "type": "text",
                    "text": "<?php $region=array('Tuscany','Emilia-Romagna')[array_rand(array('Tuscany','Emilia-Romagna'))]; echo($region); ?>"
                },
                {
                    "field": {
                        "id": "kU9fDXQTUwhC",
                        "type": "short_text",
                        "ref": "the county where the house locates"
                    },
                    "type": "text",
                    "text": "<?php $county=$region=='Tuscany'?array('Florence','Pisa')[array_rand(array('Florence','Pisa'))]:array('Bologna','Ferrara')[array_rand(array('Bologna','Ferrara'))]; echo($county); ?>"
                },
                {
                    "field": {
                        "id": "sHCAIQQJiLgA",
                        "type": "short_text",
                        "ref": "the municipality where the house locates"
                    },
                    "type": "text",
                    "text": "<?php if($county=='Florence') echo(array('Empoli','Montelupo Fiorentino')[array_rand(array('Empoli','Montelupo Fiorentino'))]); elseif($county=='Pisa') echo(array('Bientina','Buti')[array_rand(array('Bientina','Buti'))]); elseif($county=='Bologna') echo(array('Alto Reno Terme','Anzola dell\'Emilia')[array_rand(array('Alto Reno Terme','Anzola dell\'Emilia'))]); else echo(array('Argenta','Bondeno')[array_rand(array('Argenta','Bondeno'))]); ?>"
                },
                {
                    "field": {
                        "id": "n6HShSlb34Hs",
                        "type": "yes_no",
                        "ref": "there is a bus stop near the house"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "sxw10HlXUzWK",
                        "type": "yes_no",
                        "ref": "there is a supermarket near the house"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "Z52oLI8DBKwM",
                        "type": "yes_no",
                        "ref": "there is a school near the house"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "ObKCkPRvqb66",
                        "type": "number",
                        "ref": "the size of the house"
                    },
                    "type": "number",
                    "number": <?php $size = random_int(50,400); echo($size); ?>
                },
                {
                    "field": {
                        "id": "6e405GHvjxLA",
                        "type": "number",
                        "ref": "the price of the house"
                    },
                    "type": "number",
                    "number": <?=10000*floor($size*random_int(1500,2500)/10000)?>
                },				
                {
                    "field": {
                        "id": "xOD1c2M8eS4n",
                        "type": "number",
                        "ref": "the number of rooms in the house"
                    },
                    "type": "number",
                    "number": <?=floor($size/random_int(15,25))?>
                },
                {
                    "field": {
                        "id": "PtXx7zdJ2DZf",
                        "type": "multiple_choice",
                        "ref": "the furniture in the house"
                    },
                    "type": "choice",
                    "choice": {
                        "id": "<?php $furniture=array('cXPfKyVYjOps','horGXle5rytg','oumFnpiQivl1')[array_rand(array('cXPfKyVYjOps','horGXle5rytg','oumFnpiQivl1'))]; echo($furniture); ?>",
                        "ref": "<?=$furniture=='cXPfKyVYjOps'?'present':($furniture=='horGXle5rytg'?'present in part':'not present')?>",
                        "label": "<?=$furniture=='cXPfKyVYjOps'?'Yes':($furniture=='horGXle5rytg'?'Some':'No')?>"
                    }
                },
                {
                    "field": {
                        "id": "4tNH4POewECr",
                        "type": "number",
                        "ref": "the number of the bathrooms in the house"
                    },
                    "type": "number",
                    "number": <?=random_int(1,3)?>
                },
                {
                    "field": {
                        "id": "P4VWqVlR4noA",
                        "type": "number",
                        "ref": "the floor at which the house locates"
                    },
                    "type": "number",
                    "number": <?=random_int(1,10)?> 
                },
                {
                    "field": {
                        "id": "21DU73hqcITe",
                        "type": "yes_no",
                        "ref": "there is an elevator"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "0BEEz0UDU1O7",
                        "type": "yes_no",
                        "ref": "there is a garden"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "7US9haZj8QWx",
                        "type": "yes_no",
                        "ref": "the house has a balcony"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "nXwScCzk2eJc",
                        "type": "multiple_choice",
                        "ref": "the house"
                    },
                    "type": "choice",
                    "choice": {
                        "id": "<?php $condition=array('gWwIqi26mbzK','N6acVMT3IlPk','Ajgha184vmRC','nnuQr2ryYGES')[array_rand(array('gWwIqi26mbzK','N6acVMT3IlPk','Ajgha184vmRC','nnuQr2ryYGES'))]; echo($condition); ?>",
                        "ref": "<?=$condition=='gWwIqi26mbzK'?'in good conditions':($condition=='N6acVMT3IlPk'?'in fair conditions':($condition=='Ajgha184vmRC'?'in bad conditions':'in need of renovation'))?>",
                        "label": "<?=$condition=='gWwIqi26mbzK'?'Good':($condition=='N6acVMT3IlPk'?'Fair':($condition=='Ajgha184vmRC'?'Bad':'Must renovate'))?>"
                    }
                },
                {
                    "field": {
                        "id": "v5bEBo4qsdrm",
                        "type": "number",
                        "ref": "the age of the house"
                    },
                    "type": "number",
                    "number": <?=random_int(1900,2020)?>
                }
            ]
        }<?=$i<$_GET["page_size"]-1?",":""?>
    <?php } ?>],
    "total_items": <?=$_GET["page_size"]?>,
    "page_count": 1
}