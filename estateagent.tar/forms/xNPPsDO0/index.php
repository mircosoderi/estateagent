<?php header("Content-Type: application/json"); ?>
{
    "id": "xNPPsDO0",
    "type": "quiz",
    "title": "New House On Sale",
    "workspace": {
        "href": "https://api.typeform.com/workspaces/GXR73s"
    },
    "theme": {
        "href": "https://api.typeform.com/themes/qHWOQ7"
    },
    "settings": {
        "language": "en",
        "progress_bar": "proportion",
        "meta": {
            "allow_indexing": false
        },
        "hide_navigation": false,
        "is_public": true,
        "is_trial": false,
        "show_progress_bar": true,
        "show_typeform_branding": true,
        "are_uploads_public": false,
        "show_time_to_complete": true,
        "show_number_of_submissions": false,
        "show_cookie_consent": false,
        "show_question_number": true,
        "show_key_hint_on_choices": true,
        "autosave_progress": true,
        "free_form_navigation": false,
        "use_lead_qualification": false,
        "pro_subdomain_enabled": false
    },
    "thankyou_screens": [
        {
            "id": "DefaultTyScreen",
            "ref": "default_tys",
            "title": "Thanks for completing this typeform\nNow *create your own* — it's free, easy, \u0026 beautiful",
            "type": "thankyou_screen",
            "properties": {
                "show_button": true,
                "share_icons": false,
                "button_mode": "default_redirect",
                "button_text": "Create a *typeform*"
            },
            "attachment": {
                "type": "image",
                "href": "https://images.typeform.com/images/2dpnUBBkz2VN"
            }
        }
    ],
    "fields": [
        {
            "id": "Iia0aJjXyxq8",
            "title": "New House On Sale",
            "ref": "28b65245-81df-40b2-b8da-390f6c655444",
            "properties": {
                "description": "Please use this form to insert a new house on sale into the system.",
                "button_text": "Continue",
                "hide_marks": false
            },
            "type": "statement"
        },
        {
            "id": "cOAvPCL98XKr",
            "title": "In which region the house locates?",
            "ref": "the region where the house locates",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "short_text"
        },
        {
            "id": "kU9fDXQTUwhC",
            "title": "In which county the house locates?",
            "ref": "the county where the house locates",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "short_text"
        },
        {
            "id": "sHCAIQQJiLgA",
            "title": "In which municipality the house locates?",
            "ref": "the municipality where the house locates",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "short_text"
        },
        {
            "id": "n6HShSlb34Hs",
            "title": "Is the house near to a bus stop?",
            "ref": "there is a bus stop near the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "sxw10HlXUzWK",
            "title": "Is the house near to a supermarket?",
            "ref": "there is a supermarket near the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "Z52oLI8DBKwM",
            "title": "Is the house near to a school?",
            "ref": "there is a school near the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
		{
            "id": "ObKCkPRvqb66",
            "title": "How large is the house in squared metres?",
            "ref": "the size of the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "6e405GHvjxLA",
            "title": "How much is it in euros?",
            "ref": "the price of the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "xOD1c2M8eS4n",
            "title": "How many rooms are there in the house?",
            "ref": "the number of rooms in the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "PtXx7zdJ2DZf",
            "title": "Is the furniture sold with the house?",
            "ref": "the furniture in the house",
            "properties": {
                "randomize": false,
                "allow_multiple_selection": false,
                "allow_other_choice": false,
                "vertical_alignment": true,
                "choices": [
                    {
                        "id": "cXPfKyVYjOps",
                        "ref": "present",
                        "label": "Yes"
                    },
                    {
                        "id": "horGXle5rytg",
                        "ref": "present in part",
                        "label": "Some"
                    },
                    {
                        "id": "oumFnpiQivl1",
                        "ref": "not present",
                        "label": "No"
                    }
                ]
            },
            "validations": {
                "required": false
            },
            "type": "multiple_choice"
        },
        {
            "id": "4tNH4POewECr",
            "title": "How many bathrooms are there in the house?",
            "ref": "the number of the bathrooms in the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "P4VWqVlR4noA",
            "title": "At which floor is the house?",
            "ref": "the floor at which the house locates",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "21DU73hqcITe",
            "title": "Is an elevator available?",
            "ref": "there is an elevator",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "0BEEz0UDU1O7",
            "title": "Is a garden part of this house?",
            "ref": "there is a garden",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "7US9haZj8QWx",
            "title": "Is there any balcony?",
            "ref": "the house has a balcony",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "nXwScCzk2eJc",
            "title": "In what condition is the house?",
            "ref": "the house",
            "properties": {
                "randomize": false,
                "allow_multiple_selection": false,
                "allow_other_choice": false,
                "vertical_alignment": true,
                "choices": [
                    {
                        "id": "gWwIqi26mbzK",
                        "ref": "in good conditions",
                        "label": "Good"
                    },
                    {
                        "id": "N6acVMT3IlPk",
                        "ref": "in fair conditions",
                        "label": "Fair"
                    },
                    {
                        "id": "Ajgha184vmRC",
                        "ref": "in bad conditions",
                        "label": "Bad"
                    },
                    {
                        "id": "nnuQr2ryYGES",
                        "ref": "in need of renovation",
                        "label": "Must renovate"
                    }
                ]
            },
            "validations": {
                "required": false
            },
            "type": "multiple_choice"
        },
        {
            "id": "v5bEBo4qsdrm",
            "title": "How old is the house in years?",
            "ref": "the age of the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        }
    ],
    "created_at": "2025-02-11T18:04:39+00:00",
    "last_updated_at": "2025-02-11T18:04:39+00:00",
    "published_at": "2025-02-11T18:04:39+00:00",
    "_links": {
        "display": "https://44fl7nanstm.typeform.com/to/xNPPsDO0",
        "responses": "https://api.typeform.com/forms/xNPPsDO0/responses"
    }
}