<?php header("Content-Type: application/json"); ?>
{
    "id": "exad2bN7",
    "type": "quiz",
    "title": "New Client Enquiry",
    "workspace": {
        "href": "https://api.typeform.com/workspaces/GXR73s"
    },
    "theme": {
        "href": "https://api.typeform.com/themes/qHWOQ7"
    },
    "settings": {
        "language": "en",
        "progress_bar": "proportion",
        "meta": {
            "allow_indexing": false
        },
        "hide_navigation": false,
        "is_public": true,
        "is_trial": false,
        "show_progress_bar": true,
        "show_typeform_branding": true,
        "are_uploads_public": false,
        "show_time_to_complete": true,
        "show_number_of_submissions": false,
        "show_cookie_consent": false,
        "show_question_number": true,
        "show_key_hint_on_choices": true,
        "autosave_progress": true,
        "free_form_navigation": false,
        "use_lead_qualification": false,
        "pro_subdomain_enabled": false
    },
    "thankyou_screens": [
        {
            "id": "DefaultTyScreen",
            "ref": "default_tys",
            "title": "Thanks for completing this typeform\nNow *create your own* — it's free, easy, \u0026 beautiful",
            "type": "thankyou_screen",
            "properties": {
                "show_button": true,
                "share_icons": false,
                "button_mode": "default_redirect",
                "button_text": "Create a *typeform*"
            },
            "attachment": {
                "type": "image",
                "href": "https://images.typeform.com/images/2dpnUBBkz2VN"
            }
        }
    ],
    "fields": [
        {
            "id": "iuTLsqL9XTSv",
            "title": "New Client Enquiry",
            "ref": "28b65245-81df-40b2-b8da-390f6c655444",
            "properties": {
                "description": "Please use this form to specify the details of the house you are looking for.",
                "button_text": "Continue",
                "hide_marks": false
            },
            "type": "statement"
        },
        {
            "id": "pYymb6zZJ5nv",
            "title": "In which region would you like the house to be located?",
            "ref": "the region where the client is looking for a house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "short_text"
        },
        {
            "id": "tXQktMNnb46C",
            "title": "In which county would you like the house to be located?",
            "ref": "the county where the client is looking for a house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "short_text"
        },
        {
            "id": "iAIRwPLYenuk",
            "title": "In which municipality would you like the house to be located?",
            "ref": "the municipality where the client is looking for a house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "short_text"
        },
        {
            "id": "EVacOnYtcLtV",
            "title": "Should the house be near to a bus stop?",
            "ref": "the client wants a bus stop near the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "PUXp6kRobndv",
            "title": "Should the house be near to a supermarket?",
            "ref": "the client wants a supermarket near the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "IjUh272vTvLh",
            "title": "Should the house be near to a school?",
            "ref": "the client wants a school near the house",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "lSa1SEfHBUUL",
            "title": "How large should the house be in squared metres?",
            "ref": "the size of the house that the client needs",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },		
        {
            "id": "m1kuUTwLXcTT",
            "title": "How much should the house cost in euros?",
            "ref": "the price that the client is ready to pay",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "WQsUokyYyQx9",
            "title": "How many rooms should be in the house?",
            "ref": "the number of rooms that the client needs",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "nIRO4JTxtwqk",
            "title": "Should the house come with furniture inside?",
            "ref": "the client's preference in terms of the furniture in the house",
            "properties": {
                "randomize": false,
                "allow_multiple_selection": false,
                "allow_other_choice": false,
                "vertical_alignment": true,
                "choices": [
                    {
                        "id": "MUB5NCa3n1rO",
                        "ref": "yes, there must be furniture",
                        "label": "Yes"
                    },
                    {
                        "id": "ZxCJtrfmeUGQ",
                        "ref": "yes, would be good if there was some furniture",
                        "label": "Some"
                    },
                    {
                        "id": "qcFOSbWUkyld",
                        "ref": "no, I prefer the house to be empty",
                        "label": "No"
                    }
                ]
            },
            "validations": {
                "required": false
            },
            "type": "multiple_choice"
        },
        {
            "id": "Kg1n1Gosfuzf",
            "title": "How many bathrooms should be in the house?",
            "ref": "the number of bathrooms that the client needs",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "vVeK4iaEAQzT",
            "title": "At which floor should the house be?",
            "ref": "the floor at which the client wants the house to be",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        },
        {
            "id": "IVPTTCgJCqCN",
            "title": "Should an elevator be there?",
            "ref": "the client wants the elevator",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "H9xoPM8PMGU9",
            "title": "Should the house have a garden?",
            "ref": "the client wants a garden",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "yiSVtHLWbNcR",
            "title": "How important is the garden for you?",
            "ref": "the garden",
            "properties": {
                "randomize": false,
                "allow_multiple_selection": false,
                "allow_other_choice": false,
                "vertical_alignment": true,
                "choices": [
                    {
                        "id": "e1DqFZF5avBl",
                        "ref": "very important",
                        "label": "Very important"
                    },
                    {
                        "id": "6SKol1WuU6cL",
                        "ref": "quite important",
                        "label": "Quite important"
                    },
                    {
                        "id": "pFLuUMSwT8ur",
                        "ref": "not that important",
                        "label": "Not that important"
                    }
                ]
            },
            "validations": {
                "required": false
            },
            "type": "multiple_choice"
        },
        {
            "id": "cdnxjmqGIcWy",
            "title": "How important is not to have a garden for you?",
            "ref": "not having a garden",
            "properties": {
                "randomize": false,
                "allow_multiple_selection": false,
                "allow_other_choice": false,
                "vertical_alignment": true,
                "choices": [
                    {
                        "id": "DBK0tvBfbHEM",
                        "ref": "very important",
                        "label": "Very important"
                    },
                    {
                        "id": "1Vfm3w1byOvK",
                        "ref": "quite important",
                        "label": "Quite important"
                    },
                    {
                        "id": "Pcxt8KUoEVg6",
                        "ref": "not that important",
                        "label": "Not that important"
                    }
                ]
            },
            "validations": {
                "required": false
            },
            "type": "multiple_choice"
        },
        {
            "id": "O6mOuECd24G1",
            "title": "Should the house have a balcony?",
            "ref": "the client needs a balcony",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "yes_no"
        },
        {
            "id": "BKy4mal2GSIm",
            "title": "In which conditions should the house be?",
            "ref": "the client is looking for a house that",
            "properties": {
                "randomize": false,
                "allow_multiple_selection": false,
                "allow_other_choice": false,
                "vertical_alignment": true,
                "choices": [
                    {
                        "id": "5VuOlFcWb3IL",
                        "ref": "in good conditions",
                        "label": "Good"
                    },
                    {
                        "id": "AUK6Zl1XS4bt",
                        "ref": "in fair conditions",
                        "label": "Fair"
                    },
                    {
                        "id": "vw39HQopsPoK",
                        "ref": "in bad conditions",
                        "label": "Bad"
                    },
                    {
                        "id": "OtvyDvd2evbd",
                        "ref": "in need of renovation",
                        "label": "Must renovate"
                    }
                ]
            },
            "validations": {
                "required": false
            },
            "type": "multiple_choice"
        },
        {
            "id": "JavfZI0zWQMZ",
            "title": "How old should be the house in years?",
            "ref": "the age of the house that the client wants",
            "properties": {},
            "validations": {
                "required": false
            },
            "type": "number"
        }
    ],
    "variables": {
        "score": 0
    },
    "logic": [
        {
            "type": "field",
            "ref": "a4b350c7-775f-4487-b487-8b6372b64558",
            "actions": [
                {
                    "action": "jump",
                    "details": {
                        "to": {
                            "type": "field",
                            "value": "acd174ec-e82d-47e4-b34a-3d7fa86e175c"
                        }
                    },
                    "condition": {
                        "op": "is",
                        "vars": [
                            {
                                "type": "field",
                                "value": "a4b350c7-775f-4487-b487-8b6372b64558"
                            },
                            {
                                "type": "constant",
                                "value": true
                            }
                        ]
                    }
                },
                {
                    "action": "jump",
                    "details": {
                        "to": {
                            "type": "field",
                            "value": "40ec53a5-dbc5-4dc6-9d05-aca77b001040"
                        }
                    },
                    "condition": {
                        "op": "always",
                        "vars": []
                    }
                }
            ]
        },
        {
            "type": "field",
            "ref": "acd174ec-e82d-47e4-b34a-3d7fa86e175c",
            "actions": [
                {
                    "action": "jump",
                    "details": {
                        "to": {
                            "type": "field",
                            "value": "18da85fc-b105-43fb-9df3-1ae7af0cccf9"
                        }
                    },
                    "condition": {
                        "op": "always",
                        "vars": []
                    }
                }
            ]
        }
    ],
    "created_at": "2025-02-11T18:08:38+00:00",
    "last_updated_at": "2025-02-11T18:08:38+00:00",
    "published_at": "2025-02-11T18:08:38+00:00",
    "_links": {
        "display": "https://44fl7nanstm.typeform.com/to/exad2bN7",
        "responses": "https://api.typeform.com/forms/exad2bN7/responses"
    }
}