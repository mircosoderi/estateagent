<?php header("Content-Type: application/json"); ?>
{
    "items": [
        {
            "landing_id": "pc4wq8bko7ky2pc4wq7rui61rnb4107n",
            "token": "pc4wq8bko7ky2pc4wq7rui61rnb4107n",
            "response_id": "pc4wq8bko7ky2pc4wq7rui61rnb4107n",
            "response_type": "completed",
            "landed_at": "2025-02-12T16:14:24Z",
            "submitted_at": "2025-02-12T16:16:15Z",
            "metadata": {
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
                "platform": "other",
                "referer": "https://44fl7nanstm.typeform.com/to/exad2bN7",
                "network_id": "cfdf83fb6b",
                "browser": "default"
            },
            "hidden": {},
            "calculated": {
                "score": 0
            },
            "answers": [
                {
                    "field": {
                        "id": "pYymb6zZJ5nv",
                        "type": "short_text",
                        "ref": "the region where the client is looking for a house"
                    },
                    "type": "text",
                    "text": "<?php $region=array('Tuscany','Emilia-Romagna')[array_rand(array('Tuscany','Emilia-Romagna'))]; echo($region); ?>"
                },
                {
                    "field": {
                        "id": "tXQktMNnb46C",
                        "type": "short_text",
                        "ref": "the county where the client is looking for a house"
                    },
                    "type": "text",
                    "text": "<?php $county=$region=='Tuscany'?array('Florence','Pisa')[array_rand(array('Florence','Pisa'))]:array('Bologna','Ferrara')[array_rand(array('Bologna','Ferrara'))]; echo($county); ?>"
                },
                {
                    "field": {
                        "id": "iAIRwPLYenuk",
                        "type": "short_text",
                        "ref": "the municipality where the client is looking for a house"
                    },
                    "type": "text",
                    "text": "<?php if($county=='Florence') echo(array('Empoli','Montelupo Fiorentino')[array_rand(array('Empoli','Montelupo Fiorentino'))]); elseif($county=='Pisa') echo(array('Bientina','Buti')[array_rand(array('Bientina','Buti'))]); elseif($county=='Bologna') echo(array('Alto Reno Terme','Anzola dell\'Emilia')[array_rand(array('Alto Reno Terme','Anzola dell\'Emilia'))]); else echo(array('Argenta','Bondeno')[array_rand(array('Argenta','Bondeno'))]); ?>"
                },
                {
                    "field": {
                        "id": "EVacOnYtcLtV",
                        "type": "yes_no",
                        "ref": "the client wants a bus stop near the house"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "PUXp6kRobndv",
                        "type": "yes_no",
                        "ref": "the client wants a supermarket near the house"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "IjUh272vTvLh",
                        "type": "yes_no",
                        "ref": "the client wants a school near the house"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
				{
                    "field": {
                        "id": "lSa1SEfHBUUL",
                        "type": "number",
                        "ref": "the size of the house that the client needs"
                    },
                    "type": "number",
                    "number": <?php $size = random_int(50,400); echo($size); ?>
                },
                {
                    "field": {
                        "id": "m1kuUTwLXcTT",
                        "type": "number",
                        "ref": "the price that the client is ready to pay"
                    },
                    "type": "number",
                    "number": <?=10000*floor($size*random_int(1500,2500)/10000)?>
                },
                {
                    "field": {
                        "id": "WQsUokyYyQx9",
                        "type": "number",
                        "ref": "the number of rooms that the client needs"
                    },
                    "type": "number",
                    "number": <?=floor($size/random_int(15,25))?>
                },
                {
                    "field": {
                        "id": "nIRO4JTxtwqk",
                        "type": "multiple_choice",
                        "ref": "the client's preference in terms of the furniture in the house"
                    },
                    "type": "choice",
                    "choice": {
                        "id": "<?php $furniture=array_rand(['MUB5NCa3n1rO','ZxCJtrfmeUGQ','qcFOSbWUkyld']); echo($furniture); ?>",
                        "ref": "<?=$furniture=='MUB5NCa3n1rO'?'yes, there must be furniture':($furniture=='ZxCJtrfmeUGQ'?'yes, would be good if there was some furniture':'no, I prefer the house to be empty')?>",
                        "label": "<?=$furniture=='MUB5NCa3n1rO'?'Yes':($furniture=='ZxCJtrfmeUGQ'?'Some':'No')?>"
                    }
                },
                {
                    "field": {
                        "id": "Kg1n1Gosfuzf",
                        "type": "number",
                        "ref": "the number of bathrooms that the client needs"
                    },
                    "type": "number",
                    "number": <?=random_int(1,3)?>
                },
                {
                    "field": {
                        "id": "vVeK4iaEAQzT",
                        "type": "number",
                        "ref": "the floor at which the client wants the house to be"
                    },
                    "type": "number",
                    "number": <?=random_int(1,10)?> 
                },
                {
                    "field": {
                        "id": "IVPTTCgJCqCN",
                        "type": "yes_no",
                        "ref": "the client wants the elevator"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "H9xoPM8PMGU9",
                        "type": "yes_no",
                        "ref": "the client wants a garden"
                    },
                    "type": "boolean",
                    "boolean": false
                },
                {
                    "field": {
                        "id": "cdnxjmqGIcWy",
                        "type": "multiple_choice",
                        "ref": "not having a garden"
                    },
                    "type": "choice",
                    "choice": {
                        "id": "<?php $importance=array_rand(['DBK0tvBfbHEM','1Vfm3w1byOvK','Pcxt8KUoEVg6']); echo($importance); ?>",
                        "ref": "<?=$importance=='DBK0tvBfbHEM'?'very important':($importance=='1Vfm3w1byOvK'?'quite important':'not that important')?>",
                        "label": "<?=$importance=='DBK0tvBfbHEM'?'Very important':($importance=='1Vfm3w1byOvK'?'Quite important':'Not that important')?>"
                    }
                },
                {
                    "field": {
                        "id": "O6mOuECd24G1",
                        "type": "yes_no",
                        "ref": "the client needs a balcony"
                    },
                    "type": "boolean",
                    "boolean": <?=rand(0,1) == 1?'true':'false'?>
                },
                {
                    "field": {
                        "id": "BKy4mal2GSIm",
                        "type": "multiple_choice",
                        "ref": "the client is looking for a house that"
                    },
                    "type": "choice",
                    "choice": {
                        "id": "<?php $condition=array_rand(['5VuOlFcWb3IL','AUK6Zl1XS4bt','vw39HQopsPoK','OtvyDvd2evbd']); echo($condition); ?>",
                        "ref": "<?=$condition=='5VuOlFcWb3IL'?'in good conditions':($condition=='AUK6Zl1XS4bt'?'in fair conditions':($condition=='vw39HQopsPoK'?'in bad conditions':'in need of renovation'))?>",
                        "label": "<?=$condition=='5VuOlFcWb3IL'?'Good':($condition=='AUK6Zl1XS4bt'?'Fair':($condition=='vw39HQopsPoK'?'Bad':'Must renovate'))?>"
                    }
                },
                {
                    "field": {
                        "id": "JavfZI0zWQMZ",
                        "type": "number",
                        "ref": "the age of the house that the client wants"
                    },
                    "type": "number",
                    "number": <?=random_int(1900,2020)?>
                }
            ],
            "variables": [
                {
                    "key": "score",
                    "type": "number",
                    "number": 0
                }
            ]
        }
    ],
    "total_items": 1,
    "page_count": 1
}