Through this folder, we simulate the TypeForm API to overcome the limitations of free TypeForm accounts.

This folder should never be included in real applications.
----------------------------------------------------------