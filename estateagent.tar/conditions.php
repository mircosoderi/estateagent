<?php

/**
 * Conditions
 */
class Conditions
{	

	/**
     * ... is not (the same as) ...
     */
    public static function is_not_equal($params)
    {
		return $params[0] != $params[1];
	}
	
	/**
     * ... is greater than or equal to ...
     */
    public static function is_greater_or_equal($params)
    {
		return $params[0] >= $params[1];
	}
	
	/**
     * ... is lower than or equal to ...
     */
    public static function is_lower_or_equal($params)
    {
		return $params[0] <= $params[1];
	}
	
	/**
     * ... is higher than ...
     */
    public static function is_greater($params)
    {
		return $params[0] > $params[1];
	}
	
	/**
     * ... is lower than ...
     */
    public static function is_lower($params)
    {
		return $params[0] < $params[1];
	}
	
	/**
     * it is true that ...
     */
    public static function is_true($params)
    {
		return $params[0] === true;
	}
	
	/**
     * it is not true that ...
     */
    public static function is_false($params)
    {
		return $params[0] === false;
	}
	
	/**
     * ... is (the same as) ...
     */
    public static function is_equal($params)
    {		
		return $params[0] == $params[1];
	}
	
}

?>