<?php
header("Content-Type: text/csv");
echo("rules, options, total time, data time, computation time\n");
foreach(json_decode(file_get_contents("Estate Broker Benchmark.postman_collection.json"),true)["variable"] as $variable) {
	if(strpos($variable["key"], "total_time")) {
		$rules = explode("_",explode("__",$variable["key"])[3])[0];
		$options = explode("_",explode("__",$variable["key"])[2])[0];	
		echo("$rules, $options, ".$variable["value"].", ");
	}
	if(strpos($variable["key"], "data_time")) {
		echo($variable["value"].", ");
	}
	if(strpos($variable["key"], "computation_time")) {
		echo($variable["value"]."\n");
	}
} 
?>